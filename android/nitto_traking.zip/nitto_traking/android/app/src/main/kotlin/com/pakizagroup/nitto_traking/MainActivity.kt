package com.pakizagroup.nitto_traking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
